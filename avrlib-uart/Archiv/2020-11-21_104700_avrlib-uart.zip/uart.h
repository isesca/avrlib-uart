#ifndef UART_H_
#define UART_H_

#ifndef F_CPU
	//#warning "F_CPU war noch nicht definiert. Dies wird nun nachgeholt"
	#define F_CPU 16000000UL
#endif

#define F_CPU 16000000UL

#ifdef __AVR_ATmega328P__
	/* UART bits status and control register UCSR0C */
	#define UART_ASYNC_8N1 (( 1 << UCSZ01 ) | ( 1 << UCSZ00 ))
#endif

#define BAUD 9600UL

// Berechnung
#define UBRR_VAL (( F_CPU + BAUD * 8) / (BAUD * 16) - 1 )

// Reale Baudrate
#define BAUD_REAL ( F_CPU / ( 16 * ( UBRR_VAL + 1 )))

// Fehler in Promille, 1000 = kein Fehler
#define BAUD_ERROR (( BAUD_REAL * 1000) / BAUD )

#if (( BAUD_ERROR < 990 ) || ( BAUD_ERROR > 1010 ))
	#error Systematischer Fehler der Baudrate gr�sser 1% und damit zu hoch!
#endif


#define RX_BUFFER_SIZE    16 // max. 256 (8, 16, 32, 64)



uint8_t buffer_out(uint8_t *pByte);



void uart_init(void);

void uart_putc(char c);

void uart_puts(char *s);

uint8_t uart_getc(void);

void uart_gets(char* buffer, uint8_t len);








#endif /* UART_H_ */
