/*****************************************************
This program was produced by the
CodeWizardAVR V2.03.4 Standard
Automatic Program Generator
© Copyright 1998-2008 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project :
Version :
Date    : 5/20/2010
Author  :
Company :
Comments:


Chip type           : ATmega32L
Program type        : Application
Clock frequency     : 12.000000 MHz
Memory model        : Small
External RAM size   : 0
Data Stack size     : 512
*****************************************************/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>


#include "uart.h"

int main(void) {
	uint8_t c;
	uint8_t idx = 0;
	char str[32];

	DDRC  = (1<<PC2); // Alle GPIOs als Ausg�nge
	PORTC = (1<<PC2); // Pin 1 an Port C auf HI

	uart_init();
	uart_putc('>');
	_delay_ms(500);
	uart_puts("Hallo Welt\n");

	sei(); //Interrput muss eingeschaltet werden + header eingebunden!

	while(1) {

		// auslesen mit interrupt
		if ( buffer_out(&c) ) {
			str[idx] = c;
			idx++;

			// Buffer vor dem �berlauf bewahren
			if (idx > (32 - 1) ) {
				idx = 0;
			}

			// Zeilenende erkannt. Die Message zur�cksenden.
			if (c == '\n' || c == '\r') {
				uart_puts(str);
				idx = 0;
			}

		}


		// auslesen ohne interrupt
//		 if ( ( UCSR0A & ( 1<<RXC0 ) ) ) {
//			 //c = uart_getc();
//			 //uart_puts("echo: ");
//			 //uart_putc(c);
//			 //uart_putc('\n');
//
//			 uart_gets( str, sizeof(str) );
//			 uart_puts(str);
//
//			 //int line[40];
//			 //uart_gets( line, sizeof(line) / sizeof(line[0]) );
//		 }


	}

	return 0;
}
