

#include <avr/io.h>
#include <stdint.h>
#include <avr/interrupt.h>

#include "uart.h"

#ifdef __AVR_ATmega328P__
	/* UART register aliases */
	#define UART_BAUDRATE_REG        UBRR0
	#define UART_DATA_REG            UDR0
	#define UART_STATE_REG           UCSR0A // Status
	#define UART_CONTROL_REG         UCSR0B // Einstellung
	#define UART_RUNMODE_REG         UCSR0C

	/* UART bits status and control register UCSR0A */
	#define UART_RX_COMPLETE         RXC0
	#define UART_TX_COMPLETE	     TXC0
	#define UART_DATA_REG_EMPTY      UDRE0
	#define UART_FRAME_ERROR         FE0  // TODO: Abfrage implementieren
	#define UART_OVERRUN             DOR0 // TODO: Abfrage implementieren
	#define UART_PARITY_ERROR        UPE0 // TODO: Abfrage implementieren

	/* UART bits status and control register UCSR0B */
	#define UART_RX_ENABLE           RXEN0
	#define UART_TX_ENABLE           TXEN0
	#define UART_RX_INTERRUPT_ENABLE RXCIE0
	#define UART_TX_INTERRUPT_ENABLE TXCIE0
#endif

#define RX_BUFFER_MASK    (RX_BUFFER_SIZE) - 1
#define BUFFER_FAIL	   0
#define BUFFER_SUCCESS 1

volatile uint8_t index_read  = 0;
volatile uint8_t index_write = 0;
volatile uint8_t rx_buffer[RX_BUFFER_SIZE] = {};


uint8_t buffer_in(uint8_t byte) {

	// Determine the index of the current data field
	uint8_t index = ( ( index_write + 1 ) & RX_BUFFER_MASK );

	// Check if there is space for the current data field
	if ( index_read == index ) {
		return BUFFER_FAIL;
		// Buffer Overflow
		//TODO: Error Handling
	}

	// Write data to buffer. (The mask avoids errors when the buffer is not initialized correctly)
	rx_buffer[index_write & RX_BUFFER_MASK] = byte;

	// Write complete => increase index
	index_write = index;

	return BUFFER_SUCCESS;
}

uint8_t buffer_out(uint8_t *pByte) {

	// No data available.
	if ( index_read == index_write ) {
		return BUFFER_FAIL;
		// TODO: Error Handling
	}

	// Save value from buffer to output variable
	*pByte = rx_buffer[index_read];

	// read action successful => increase index.
	index_read = (index_read + 1) & RX_BUFFER_MASK;

	return BUFFER_SUCCESS;
}


//#define UART_MAXSTRLEN 10
//volatile uint8_t uart_str_complete = 0;
//volatile uint8_t uart_str_count    = 0;
//volatile char uart_string[UART_MAXSTRLEN + 1];

ISR(USART_RX_vect) {
	uint8_t next, err;

	next = UART_DATA_REG;

	buffer_in(next);


	// Ungebuffertes auslesen:
//	if ( uart_str_complete == 0 ) {
//		// UART is ready.
//		if ( next != '\n' && next != '\r' ) {
//			// Save byte to buffer.
//			uart_string[uart_str_count] = next;
//			uart_str_count++;
//
//		}
//		else {
//			// End of the message is detected.
//			uart_string[uart_str_count] = '\0';
//			uart_str_count = 0;
//		}
//
//	}
//	else {
//		// UART currently in use.
//		// TODO: Es wird zu schnell gelesen
//	}

	uart_putc(next);
}



void uart_init(void) {
	UART_BAUDRATE_REG = UBRR_VAL;

	// UART TX einschalten
	UART_CONTROL_REG |= ( 1 << UART_TX_ENABLE ); // Transmit enable
	UART_CONTROL_REG |= ( 1 << UART_RX_ENABLE ); // Receive enable
	UART_CONTROL_REG |= ( 1 << UART_RX_INTERRUPT_ENABLE ); // Receive complete interrput enable einschalten

	// Frame Format
	UART_RUNMODE_REG = UART_ASYNC_8N1;
}

void uart_putc(char c) {

	/* TODO: senden und blockieren */
	while ( !(UART_STATE_REG & ( 1 << UART_DATA_REG_EMPTY ) ) ) {
		/* Warten bis UART Modul bereit zum senden. */
	}

	UART_DATA_REG = c;

	/* TODO: senden ohne zu blokieren */
	//if( UART_STATE_REG & ( 1 << UART_DATA_REG_EMPTY ) ) {
	//	UART_DATA_REG = c;
	//}

}

void uart_puts(char *s) {
	while( *s ) { // Solange *s != '\0'
		uart_putc( *s );
		s++;
	}
}


uint8_t uart_getc(void) {
	while ( !(UART_STATE_REG & ( 1 << UART_RX_COMPLETE ) ) ) {
		// Warten bis Zeichen verf�gbar
	}

	return UART_DATA_REG;
}

void uart_gets(char *buffer, uint8_t len) {
	uint8_t val;
	uint8_t idx;

	val = uart_getc();

	while( val != '\n' && idx < (len - 1) ) {
		*buffer++ = val;
		idx++;
		val = uart_getc();
	}

	*buffer = '\0';
}

